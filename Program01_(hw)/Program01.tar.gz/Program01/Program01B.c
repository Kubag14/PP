#include <stdio.h>

int main()
{
	printf("Hello ");
	printf("world! ");
	printf("\n");
	return 0;
}
