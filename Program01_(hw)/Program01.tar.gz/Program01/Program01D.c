#include <stdio.h>

int main()
{
	printf("\vHello\tworld!\n");
	printf("Hello \"world!\"\n");
	return 0;
}
