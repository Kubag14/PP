#include <stdio.h>
#include <stdlib.h>

void wypiszTekst(char tekst[]);

void wypiszTekstP(FILE *wo, char tekst[]);

void czytajTekst(FILE *wi, char tekst[],int max);

void kopiujTekst(char skad[],char dokad[],int max);

void wszystkieZnaki(char tekst[]);

void czarneZnaki(char tekst[]);

void linie(char tekst[]);

void slowa(char tekst[]);

void wszystkieZnakiP(FILE *wo, char tekst[]);

void czarneZnakiP(FILE *wo, char tekst[]);

void linieP(FILE *wo, char tekst[]);

void slowaP(FILE *wo, char tekst[]);