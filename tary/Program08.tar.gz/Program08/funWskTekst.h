#include <stdio.h>
#include <stdlib.h>

void wypiszTekstP(FILE *wo, const char *restrict tekst);

void czytajTekstP(FILE *wi, char *restrict tekst,int max);

void wszystkieZnakiP(FILE *wo, const char *restrict tekst);

void czarneZnakiP(FILE *wo, const char *restrict tekst);

void linieP(FILE *wo, const char *restrict tekst);

void slowaP(FILE *wo, const char *restrict tekst);